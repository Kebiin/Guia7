package com.segundo.modelo;

import lombok.Data;

/**
 *
 * @author ldric
 */
@Data
public class Usuario {
    private String cedula;
    private String nombre;
    private String email;
    private String clave;
}
