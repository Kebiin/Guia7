
package com.segundo.pro;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.beans.factory.annotation.Value;
import com.segundo.modelo.Usuario;
import java.util.Arrays;
import java.util.List;
/**
 *
 * @author familiy
 */



@Controller
@Slf4j
public class ControladorInicio {
    @Value("${index.mensaje}")
    String dato;
    @GetMapping("/")
    public String inicio(Model modelo){
        String mensaje = "saludos con informacion de paso";
        modelo.addAttribute("mensaje", mensaje);
        modelo.addAttribute("dato", dato);
        Usuario u = new Usuario();
        u.setCedula("654");
        u.setClave("amn");
        u.setNombre("mario cardenas");
        u.setEmail("cardenas.com");
        modelo.addAttribute("usuario a", u);
        Usuario u2 = new Usuario();
        u2.setCedula("1235");
        u2.setClave("345fx");
        u2.setNombre("ana lopez");
        u2.setEmail("lopez.com");
       
        
        Usuario u3 = new Usuario();
        u3.setCedula("554");
        u3.setClave("7acvbfgh7");
        u3.setNombre("carla mia");
        u3.setEmail("mia.com");
        
        
        List<Usuario> ListaUsuarios = Arrays.asList(u2,u3);
        modelo.addAttribute("usuarios", ListaUsuarios);
        log.info("Ejecutando el controlador ");
        return "index";
    }
}
